# AnswerThis.io Clone (Starter)

A minimal, end-to-end scaffold of your described repository: FastAPI backend, static React frontend, and Postgres. Swap stubs with real providers (OpenAI/Anthropic, arXiv/Crossref APIs, Pinecone/Milvus).

## Quickstart (Docker)
```bash
docker-compose up
```
API: http://localhost:8000/docs  
Frontend: http://localhost:5173

## Local Dev (Backend)
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export DATABASE_URL=postgresql+psycopg2://postgres:postgres@localhost:5432/answerthis
uvicorn src.server:app --reload
```

Run SQL migrations:
```bash
psql $DATABASE_URL -f src/database/migrations/create_tables.sql
```

## Local Dev (Frontend)
A barebone static setup that serves pages with React Router:
```bash
cd frontend
npm install
npm run dev
```

## Wire up real services
- **LLM**: Implement `services/ai_service/llm_connector.py`
- **Vector DB**: Implement `database/connectors/vector_db_connector.py`
- **External search APIs**: Implement `services/search_service/external_apis.py`
- **Auth**: JWT secret via `JWT_SECRET`

## Notes
This is intentionally lightweight but complete—every listed file exists with working starter code.
