from loguru import logger
from fastapi import FastAPI

def setup_logging(app: FastAPI):
    logger.add("app.log", rotation="10 MB")
    @app.middleware("http")
    async def log_requests(request, call_next):
        logger.info(f"{request.method} {request.url}")
        response = await call_next(request)
        logger.info(f"Completed with status {response.status_code}")
        return response
