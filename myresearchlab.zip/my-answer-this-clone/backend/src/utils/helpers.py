def paginate(items, page: int = 1, size: int = 20):
    start = (page-1)*size
    end = start + size
    return items[start:end]
