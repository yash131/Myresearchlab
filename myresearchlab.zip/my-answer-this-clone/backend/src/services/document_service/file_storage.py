import os, shutil
from fastapi import UploadFile
BASE = os.getenv("UPLOAD_DIR", "/mnt/data/uploads")

async def save_upload(user_id: int, file: UploadFile) -> str:
    os.makedirs(BASE, exist_ok=True)
    dest = os.path.join(BASE, f"user{user_id}_{file.filename}")
    with open(dest, "wb") as f:
        while chunk := await file.read(1024 * 1024):
            f.write(chunk)
    await file.close()
    return dest
