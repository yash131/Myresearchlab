def normalize_title(t: str) -> str:
    return " ".join(t.split()).strip().title()
