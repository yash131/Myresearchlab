# Minimal search stubs; replace with real APIs (arXiv, Crossref, PubMed, etc.).
def search_arxiv(query: str):
    return [{
        "title": f"ArXiv result for {query} #{i+1}",
        "url": f"https://arxiv.org/abs/000{i}",
        "authors": ["First Author", "Second Author"],
        "year": 2024
    } for i in range(10)]

def search_crossref(query: str):
    return [{
        "title": f"Crossref result for {query} #{i+1}",
        "doi": f"10.0000/example{i}",
        "year": 2023
    } for i in range(10)]
