from .llm_connector import generate
from .semantic_search import most_similar

# Minimal RAG: retrieve from an in-memory corpus placeholder.
CORPUS = [
    "Retrieval-Augmented Generation (RAG) combines search with generation.",
    "Vector databases like Pinecone or Milvus store embeddings for fast similarity.",
    "Citations are crucial for academic QA systems.",
    "FastAPI and React can power modern research assistants."
]

def rag_qa(project_id: int, query: str):
    retrieved = most_similar(query, CORPUS, top_k=3)
    context = "\n".join(CORPUS[i] for i,_ in retrieved)
    prompt = f"""Use the context to answer the query.
Context:
{context}

Query: {query}
"""
    answer = generate(prompt)
    sources = [{"snippet": CORPUS[i], "score": score} for i, score in retrieved]
    return answer, sources
