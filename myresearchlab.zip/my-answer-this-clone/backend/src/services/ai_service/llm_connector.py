# Swap this for your preferred LLM provider. Here we stub a response.
def generate(prompt: str) -> str:
    return f"""[LLM STUB] You asked: {prompt}
This is a placeholder response. Connect OpenAI/Anthropic/etc. here."""
