from typing import List, Tuple
import numpy as np

# Stub embeddings function
def embed(texts: List[str]) -> np.ndarray:
    rng = np.random.default_rng(42)
    return rng.normal(size=(len(texts), 384))

def most_similar(query: str, corpus: List[str], top_k: int = 5) -> List[Tuple[int, float]]:
    qv = embed([query])[0]
    cv = embed(corpus)
    sims = (cv @ qv) / (np.linalg.norm(cv, axis=1) * np.linalg.norm(qv) + 1e-9)
    idx = np.argsort(-sims)[:top_k]
    return [(int(i), float(sims[i])) for i in idx]
