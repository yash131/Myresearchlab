# FastAPI uses dependency-based auth in this project; see auth_controller.get_current_user
# If you want ASGI middleware, you can extend here.
