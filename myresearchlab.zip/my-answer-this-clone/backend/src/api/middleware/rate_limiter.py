# For brevity, use a naive in-memory rate limiter. Replace with Redis in production.
from time import time
from fastapi import Request, HTTPException

WINDOW = 60
MAX_REQ = 120
BUCKET = {}

async def limiter(request: Request, call_next):
    ip = request.client.host
    now = int(time())
    slot = now // WINDOW
    key = f"{ip}:{slot}"
    BUCKET[key] = BUCKET.get(key, 0) + 1
    if BUCKET[key] > MAX_REQ:
        raise HTTPException(status_code=429, detail="Rate limit exceeded")
    return await call_next(request)
