def get_profile(user):
    return {"id": user.id, "email": user.email, "name": user.name, "bio": user.bio}

def update_profile(user, updates: dict):
    for k, v in updates.items():
        setattr(user, k, v)
    from ...database.connectors.pg_connector import session_scope
    with session_scope() as db:
        db.merge(user)
        db.commit()
    return get_profile(user)
