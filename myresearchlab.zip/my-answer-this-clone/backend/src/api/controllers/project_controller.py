from ...database.connectors.pg_connector import session_scope
from ...models.project import Project
from ...models.paper import Paper

def list_projects(user):
    with session_scope() as db:
        items = db.query(Project).filter(Project.owner_id==user.id).all()
        return [{"id": p.id, "title": p.title, "description": p.description} for p in items]

def create_project(user, data: dict):
    with session_scope() as db:
        proj = Project(title=data["title"], description=data.get("description"), owner_id=user.id)
        db.add(proj); db.commit(); db.refresh(proj)
        return {"id": proj.id, "title": proj.title, "description": proj.description}

def get_project(user, pid: int):
    with session_scope() as db:
        p = db.get(Project, pid)
        if not p or p.owner_id != user.id: return None
        return {"id": p.id, "title": p.title, "description": p.description}

def add_paper(user, data: dict):
    with session_scope() as db:
        p = db.get(Project, data["project_id"])
        if not p or p.owner_id != user.id:
            raise ValueError("Project not found")
        paper = Paper(project_id=p.id, title=data["title"], abstract=data.get("abstract"), source_url=data.get("source_url"))
        db.add(paper); db.commit(); db.refresh(paper)
        return {"id": paper.id, "title": paper.title}
