from ...services.ai_service.rag_engine import rag_qa
from ...services.search_service.external_apis import search_arxiv, search_crossref

def ask_question(user, project_id: int, query: str):
    answer, sources = rag_qa(project_id, query)
    return {"answer": answer, "sources": sources}

def web_search(query: str):
    return {
        "arxiv": search_arxiv(query)[:5],
        "crossref": search_crossref(query)[:5]
    }
