def list_citations(user):
    # Placeholder; wire to your citations store
    return [{"id": 1, "text": "Doe, 2024, On RAG Systems", "url": "https://example.org"}]
