from fastapi import UploadFile
from ...services.document_service.pdf_parser import extract_text_from_pdf
from ...services.document_service.file_storage import save_upload
from ...database.connectors.pg_connector import session_scope
from ...models.paper import Paper

async def upload_pdf(user, file: UploadFile):
    path = await save_upload(user.id, file)
    text = extract_text_from_pdf(path)
    # Optionally index text into vector DB here
    with session_scope() as db:
        paper = Paper(project_id=None, title=file.filename, abstract=text[:400], source_url=path)
        db.add(paper); db.commit(); db.refresh(paper)
        return {"paper_id": paper.id, "filename": file.filename, "chars": len(text)}
