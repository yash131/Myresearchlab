from fastapi import APIRouter, Depends, UploadFile, File
from ...api.controllers.auth_controller import get_current_user
from ...api.controllers.document_controller import upload_pdf
router = APIRouter()

@router.post("/upload")
async def upload(file: UploadFile = File(...), current=Depends(get_current_user)):
    return await upload_pdf(current, file)
