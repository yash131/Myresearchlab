from fastapi import APIRouter, Depends
from ...api.controllers.user_controller import get_profile, update_profile
from ...api.controllers.auth_controller import get_current_user
from pydantic import BaseModel

router = APIRouter()

class UpdateProfilePayload(BaseModel):
    name: str | None = None
    bio: str | None = None

@router.get("/profile")
def profile(current=Depends(get_current_user)):
    return get_profile(current)

@router.put("/profile")
def profile_update(payload: UpdateProfilePayload, current=Depends(get_current_user)):
    return update_profile(current, payload.model_dump(exclude_none=True))
