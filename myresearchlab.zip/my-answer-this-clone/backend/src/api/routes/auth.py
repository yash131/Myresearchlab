from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from ...services.user_service.password_hasher import verify_password, get_password_hash
from ...database.connectors.pg_connector import get_session
from ...models.user import User
from ...api.controllers.auth_controller import create_access_token, get_current_user

router = APIRouter()

class SignupPayload(BaseModel):
    email: str
    password: str
    name: str

class LoginPayload(BaseModel):
    email: str
    password: str

@router.post("/signup")
def signup(payload: SignupPayload, db=Depends(get_session)):
    if db.query(User).filter(User.email==payload.email).first():
        raise HTTPException(status_code=400, detail="Email already exists")
    user = User(email=payload.email, name=payload.name, password_hash=get_password_hash(payload.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"id": user.id, "email": user.email, "name": user.name}

@router.post("/login")
def login(payload: LoginPayload, db=Depends(get_session)):
    user = db.query(User).filter(User.email==payload.email).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token({"sub": str(user.id)})
    return {"access_token": token, "token_type": "bearer"}

@router.get("/me")
def me(current=Depends(get_current_user)):
    return {"id": current.id, "email": current.email, "name": current.name}
