from fastapi import APIRouter, Depends, UploadFile, File
from pydantic import BaseModel
from ...api.controllers.auth_controller import get_current_user
from ...api.controllers.research_controller import ask_question, web_search

router = APIRouter()

class AskPayload(BaseModel):
    project_id: int
    query: str

@router.post("/ask")
def ask(payload: AskPayload, current=Depends(get_current_user)):
    return ask_question(current, payload.project_id, payload.query)

class SearchPayload(BaseModel):
    query: str

@router.post("/search")
def search(payload: SearchPayload, current=Depends(get_current_user)):
    return web_search(payload.query)
