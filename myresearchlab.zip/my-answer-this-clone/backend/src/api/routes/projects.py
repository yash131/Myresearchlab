from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from ...api.controllers.auth_controller import get_current_user
from ...api.controllers.project_controller import list_projects, create_project, get_project, add_paper
router = APIRouter()

class ProjectPayload(BaseModel):
    title: str
    description: str | None = None

class PaperPayload(BaseModel):
    project_id: int
    source_url: str | None = None
    title: str
    abstract: str | None = None

@router.get("")
def get_all(current=Depends(get_current_user)):
    return list_projects(current)

@router.post("")
def create(payload: ProjectPayload, current=Depends(get_current_user)):
    return create_project(current, payload.model_dump())

@router.get("/{project_id}")
def details(project_id: int, current=Depends(get_current_user)):
    proj = get_project(current, project_id)
    if not proj:
        raise HTTPException(status_code=404, detail="Not found")
    return proj

@router.post("/add-paper")
def addpaper(payload: PaperPayload, current=Depends(get_current_user)):
    return add_paper(current, payload.model_dump())
