from fastapi import APIRouter, Depends
from ...api.controllers.auth_controller import get_current_user
from ...api.controllers.citation_controller import list_citations
router = APIRouter()

@router.get("")
def list_all(current=Depends(get_current_user)):
    return list_citations(current)
