from sqlalchemy import Column, Integer, String, Text, ForeignKey
from ..database.connectors.pg_connector import Base

class Paper(Base):
    __tablename__ = "papers"
    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    title = Column(String(512), nullable=False)
    abstract = Column(Text, nullable=True)
    source_url = Column(Text, nullable=True)
