from sqlalchemy import Column, Integer, Text, ForeignKey
from ..database.connectors.pg_connector import Base

class Citation(Base):
    __tablename__ = "citations"
    id = Column(Integer, primary_key=True, index=True)
    paper_id = Column(Integer, ForeignKey("papers.id"), nullable=True)
    citation_text = Column(Text, nullable=False)
    url = Column(Text, nullable=True)
