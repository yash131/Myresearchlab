from sqlalchemy.orm import declarative_base, relationship
from sqlalchemy import Column, Integer, String, Text
from ..database.connectors.pg_connector import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    name = Column(String(255), nullable=False)
    password_hash = Column(String(255), nullable=False)
    bio = Column(Text, nullable=True)
