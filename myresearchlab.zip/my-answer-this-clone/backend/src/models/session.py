from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Text
from ..database.connectors.pg_connector import Base

class Session(Base):
    __tablename__ = "sessions"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    query = Column(Text, nullable=True)
    response = Column(Text, nullable=True)
