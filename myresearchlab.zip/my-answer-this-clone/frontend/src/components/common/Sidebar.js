import React from "react";
import { Link } from "react-router-dom";

export default function Sidebar(){
  return (
    <aside className="sidebar">
      <ul>
        <li><Link to="/research">Research</Link></li>
        <li><Link to="/projects">Projects</Link></li>
        <li><Link to="/library">Library</Link></li>
        <li><Link to="/account">Account</Link></li>
      </ul>
    </aside>
  )
}
