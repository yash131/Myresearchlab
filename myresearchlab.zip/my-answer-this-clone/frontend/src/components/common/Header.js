import React from "react";
import { Link } from "react-router-dom";

export default function Header(){
  return (
    <header className="header">
      <Link to="/" className="logo">AnswerThis Clone</Link>
      <nav>
        <Link to="/research">Research</Link>
        <Link to="/projects">Projects</Link>
        <Link to="/library">Library</Link>
        <Link to="/dashboard">Dashboard</Link>
      </nav>
    </header>
  )
}
