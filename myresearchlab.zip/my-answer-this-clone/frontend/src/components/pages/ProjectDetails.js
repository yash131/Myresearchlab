import React from "react";
export default function ProjectDetails(){ return (<div><h1>ProjectDetails</h1><p>A specific project's details and activity.</p></div>) }
