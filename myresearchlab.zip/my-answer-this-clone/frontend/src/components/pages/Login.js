import React from "react";
export default function Login(){ return (<div><h1>Login</h1><p>Sign in to access your research workspace.</p></div>) }
