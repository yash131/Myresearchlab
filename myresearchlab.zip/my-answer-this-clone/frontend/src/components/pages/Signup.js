import React from "react";
export default function Signup(){ return (<div><h1>Signup</h1><p>Create an account to start projects and save papers.</p></div>) }
