import React from "react";
export default function PrivacyPolicy(){ return (<div><h1>PrivacyPolicy</h1><p>We respect your privacy.</p></div>) }
