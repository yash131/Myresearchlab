import React from "react";
export default function Research(){ return (<div><h1>Research</h1><p>Ask questions, perform web searches, and see citations.</p></div>) }
