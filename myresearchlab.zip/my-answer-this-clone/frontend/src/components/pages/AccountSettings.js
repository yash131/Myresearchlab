import React from "react";
export default function AccountSettings(){ return (<div><h1>AccountSettings</h1><p>Update your profile and preferences.</p></div>) }
