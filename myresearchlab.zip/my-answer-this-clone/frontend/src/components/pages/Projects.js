import React from "react";
export default function Projects(){ return (<div><h1>Projects</h1><p>List of your projects.</p></div>) }
