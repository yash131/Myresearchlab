import React from "react";
export default function Pricing(){ return (<div><h1>Pricing</h1><p>Simple pay-as-you-go for AI usage.</p></div>) }
