import React from "react";
export default function Home(){ return (<div><h1>Home</h1><p>Your AI research copilot. Upload PDFs, search the web, and chat with citations.</p></div>) }
