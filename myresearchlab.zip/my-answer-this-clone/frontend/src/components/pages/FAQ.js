import React from "react";
export default function FAQ(){ return (<div><h1>FAQ</h1><p>Common questions and answers.</p></div>) }
