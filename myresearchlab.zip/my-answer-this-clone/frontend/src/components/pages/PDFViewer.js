import React from "react";
export default function PDFViewer(){ return (<div><h1>PDFViewer</h1><p>Upload and read PDFs with extraction.</p></div>) }
